<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'webecks_sb');

/** MySQL database username */
define('DB_USER', 'webecks_sb');

/** MySQL database password */
define('DB_PASSWORD', 'IxRgD$D}sTAq$Vd3%V');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Z?~1JGyrImnl_3E=0%PP(*KE`:eWS<`k~sDt3Kpt,az)7 4Ea^1uUV:w<hnUT])o');
define('SECURE_AUTH_KEY',  '&YLV:hHvz%Kw[8tMFmSg0tDUL%(:STf: [+6%bb~GIgp#ysz7f2R-Eg W*KCL:8n');
define('LOGGED_IN_KEY',    'R@3G^hcuPgEdX|kj09pl>nUkMLHn+S9{YY!!,e(7>nBqiZ<{S1kT+B%|^U Ap,c_');
define('NONCE_KEY',        ':sr$/:BVDDjUFIB>4Si,&|_Bk<(uKUpWR{J:{ne;HNklqoYp(Y36W]PZ.j }-K,{');
define('AUTH_SALT',        '?8@zysU7eaOD~u(~/6](KNKywvLC2zXy-:cRoJuM_)XTN`{WpDisLou1)bCEExjR');
define('SECURE_AUTH_SALT', 'O@lHty_j#J767>:cR7~); xW:`JDrrcD-VkOMkJ+{R`=JNA/R#JJ3j+}9]V+fhy`');
define('LOGGED_IN_SALT',   '*par[?bGDa7ihvTT%#^#JNrYWxUcy{9CalEQp7b3eP#c(&5<10b#|j*~#x]&*0IM');
define('NONCE_SALT',       '[ka 2Q+fj3IH8df|$pa|@%`)q/S9W4Qq.5]*:~$hfI52<Oq5WLh5CQl?xRufav1q');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp7sb_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', true);

/** Remove revisions */
define('AUTOSAVE_INTERVAL', 300);
define('WP_POST_REVISIONS', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
